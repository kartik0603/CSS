# Floating Color Orbs

A Pen created on CodePen.io. Original URL: [https://codepen.io/hylobates-lar/pen/bGEQXgm](https://codepen.io/hylobates-lar/pen/bGEQXgm).

